package com.tutorialspoint.lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class Searcher {
	   //This class act as a core component which reads/searches indexes created after the indexing process. 
	   //It takes directory instance pointing to the location containing the indexes.

	   IndexSearcher indexSearcher;
	   
	   //TermQuery is the most commonly-used query object 
	   //and is the foundation of many complex queries that Lucene can make use of.
	   //Parsing of a query is the process by which this decision making is done that for a given query, 
	   //calculating how many different ways there are in which the query can run. 
	   QueryParser queryParser;
	   
	   //Query is an abstract class and contains various utility methods 
	   //and is the parent of all types of queries that Lucene uses during search process.
	   Query query;
	   
	   public Searcher(String indexDirectoryPath) 
	      throws IOException {
	      Directory indexDirectory = 
	         FSDirectory.open(new File(indexDirectoryPath));
	      indexSearcher = new IndexSearcher(indexDirectory);
	      queryParser = new QueryParser(Version.LUCENE_36,
	         LuceneConstants.CONTENTS,
	         new StandardAnalyzer(Version.LUCENE_36));
	   }
	   
	   //TopDocs points to the top N search results which matches the search criteria. 
	   //It is a simple container of pointers to point to documents which are the output of a search result.
	   
	   public TopDocs search( String searchQuery) 
	      throws IOException, ParseException {
	      query = queryParser.parse(searchQuery);
	      return indexSearcher.search(query, LuceneConstants.MAX_SEARCH);
	   }

	   public Document getDocument(ScoreDoc scoreDoc) 
	      throws CorruptIndexException, IOException {
	      return indexSearcher.doc(scoreDoc.doc);	
	   }

	   public void close() throws IOException {
	      indexSearcher.close();
	   }
}
