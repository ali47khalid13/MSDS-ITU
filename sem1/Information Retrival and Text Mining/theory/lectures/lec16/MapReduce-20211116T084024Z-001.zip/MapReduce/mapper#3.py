#!/usr/bin/env python
"""mapper.py"""
import re
import sys
infile=sys.stdin
next(infile)
i=0
# input comes from STDIN (standard input)
for row in infile:
    # remove leading and trailing whitespace
    values = [x.strip() for x in row.split(',')]

    print ('%s\t%s\t%s\t%s\t%s' % (values[1],values[2],values[3],values[4],1))
        # write the results to STDOUT (standard output);
        # what we output here will be the input for the
        # Reduce step, i.e. the input for reducer.py
    
        
      