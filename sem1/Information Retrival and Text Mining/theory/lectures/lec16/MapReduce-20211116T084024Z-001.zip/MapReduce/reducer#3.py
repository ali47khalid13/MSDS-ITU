#!/usr/bin/env python
"""reducer.py"""
from heapq import nlargest
from operator import itemgetter
import sys

current_word = None
current_count = 0
word = None
N = 20
word_dict={}
total_female=0
total_male=0
male_LR= []
female_LR= []
total_val=0

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    print('%s' %(line))
    # parse the input we got from mapper.py
    male, female, lm, lf, val = line.split('\t')
    
    total_female = total_female + (int(female)*float(lf))
    total_male = total_male + (int(male)*float(lm))
    male_LR.append(float(lm))
    female_LR.append(float(lf))
    total_val = total_val + int(val)

print('%s\t%s' % ("Total Rows :",(int(total_val))))   
print('%s\t%s' % ("Total Male Literates :",(int(total_male))))
print('%s\t%s' % ("Total Female Literates :",(int(total_female))))
print('%s\t%s' % ("Average Literacy Rate For Male :", sum(male_LR)/len(male_LR)))
print('%s\t%s' % ("Average Literacy Rate For Female :", sum(female_LR)/len(female_LR)))
print('%s\t%s' % ("Maximum Literacy Rate For Male :", max(male_LR)))
print('%s\t%s' % ("Minimum Literacy Rate For Male :", min(male_LR)))
print('%s\t%s' % ("Maximum Literacy Rate For female :", max(female_LR)))
print('%s\t%s' % ("Minimum Literacy Rate For female :", min(female_LR)))